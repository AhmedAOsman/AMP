rosservice call /arlobot_unplug True

