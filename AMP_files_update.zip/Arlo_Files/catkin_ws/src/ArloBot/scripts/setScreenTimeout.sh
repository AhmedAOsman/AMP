dconf write /org/gnome/desktop/session/idle-delay $1

