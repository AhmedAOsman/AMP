echo "(set! voice_default 'voice_en1_mbrola)" >> /etc/festival.scm

