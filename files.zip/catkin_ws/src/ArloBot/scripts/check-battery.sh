upower -d|egrep "percentage|model"
