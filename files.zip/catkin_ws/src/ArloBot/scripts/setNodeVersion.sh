#!/bin/bash
# All this does is set what node version all of my stuff uses.
# Since the merge and update to 4.0, I have found a need to stick to a specific relaese to keep
# things stable
export node_version=8.4.0

