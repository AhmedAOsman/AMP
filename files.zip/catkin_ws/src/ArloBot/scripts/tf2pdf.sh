rosrun tf view_frames
evince frames.pdf 
rm frames.gv
rm frames.pdf

